var AWS = require('aws-sdk');
var mimemessage = require('mimemessage');
var fs = require('fs');
AWS.config.loadFromPath('/home/aws.json');
var awsInit = new AWS.SES({apiVersion: '2010-12-01'});
exports.sendReset = function(email, link){
	var template = `
	<h1>StoreGuard Password Reset</h1>
	<p>Thank you for requesting a password reset. In order to reset your password, please click the link below. If you did not request a password reset, disregard this email.
	<br />
	<br />
	<a href="${link}">Verify</a>
	<br />
	<br />
	Note: if you are unable to click the link above, you may manually verify by pasting the following link into your browser's address bar: ${link}
	<br />
	<br />
	Copyright John Jusko, 2020.
	</p>
	`;
	var params = {
	  Destination: { /* required */
		CcAddresses: [
		  /* more items */
		],
		ToAddresses: [
		  email
		  /* more items */
		]
	  },
	  Message: { /* required */
		Body: { /* required */
		  Html: {
		   Charset: "UTF-8",
		   Data: template
		  },
		  Text: {
		   Charset: "UTF-8",
		   Data: "TEXT_FORMAT_BODY"
		  }
		 },
		 Subject: {
		  Charset: 'UTF-8',
		  Data: 'Reset your StoreGuard Password'
		 }
		},
	  Source: 'admin@storeguard.app', /* required */
	  ReplyToAddresses: [
		 'johnjuskobusiness@gmail.com',
		/* more items */
	  ],
	};
	var sendPromise = awsInit.sendEmail(params).promise();
	return new Promise(function(resolve, reject){
		sendPromise.then(
  function(data) {
    resolve(data.MessageId);
  }).catch(
    function(err) {
    reject(err);
  });
	});
	
}
exports.sendCSV = function(email, filePath){
	//console.log('sending csv to email ' + email);
	var mailContent = mimemessage.factory({contentType: 'multipart/mixed',body: []});
	mailContent.header('From', 'StoreGuard Administratior <noreply@storeguard.app>');
	mailContent.header('To', email);
	mailContent.header('Subject', 'Your StoreGuard Scans Have Been Exported');
	
	var template = `
	<h1>StoreGuard Scan Export</h1>
	<p>Thank you for exporting your scan history.  The scan file may be opened in Google Sheets, Excel, or any other functioning spreadsheet program. Your file has been attached to this email, and you may view it below.
	<br />
	<br />
	Copyright John Jusko, 2020.
	</p>
	`;
	
	var htmlEntity = mimemessage.factory({
	   contentType: 'text/html;charset=utf-8',
	   body: template
	});
	mailContent.body.push(htmlEntity);
	fs.readFile(filePath, (err, data) => {
		var attachmentEntity = mimemessage.factory({
			contentType: 'text/plain',
			contentTransferEncoding: 'base64',
			body: data.toString('base64').replace(/([^\0]{76})/g, "$1\n")
		});
		attachmentEntity.header('Content-Disposition', 'attachment ;filename="export.csv"');
		mailContent.body.push(attachmentEntity);
	//	console.log('got all the way to mail send');
	//	console.log(mailContent.toString());
		awsInit.sendRawEmail({RawMessage: {Data: mailContent.toString()}}, (err, sesdata, res) => {
			console.log(err);
			console.log(sesdata);
			console.log(res);
		});
	});	
}