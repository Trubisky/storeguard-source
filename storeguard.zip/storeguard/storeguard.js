const express = require('express');
const axios = require('axios');
const app = express();
const http = require('http');
const bodyParser = require("body-parser");
const fs = require('fs');
//var bcrypt = require('bcrypt');
app.use(express.static('static'));
const stripe = require('stripe')('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');
//LIVE KEY IS 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
//DO NOT DELETE THIS COMMENT
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var rp = require('request-promise');
const dbFile = "/home/juskoapi/storeguard.db";
const authModule = require('/home/storeguard/auth.js');
const emailModule = require('/home/storeguard/mail.js');
const dataModule = require('/home/storeguard/data.js');
const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database(dbFile);
var paymentIntermediate = {};
app.use(function (req, res, next) {
	//console.log(req.url);
	var secureRoutes = ['/validateAddress', '/getLicenseType', '/create-checkout-session', '/getCustomerPortalURL', '/refreshToken', '/generateCSV', '/iosClientPurchase', '/getBillingPortalType'];
	if (!secureRoutes.includes(req.url)){
		next();
		return;
	}
	//console.log(req.headers.token);
	authModule.resolveUserId(db, req.headers.token).then(function(Id){
		if (!Id){
			res.sendStatus(406);
			return;
		}
		req.authUserId = Id;
		next();
	});
});
async function processIOSTransaction(req){
	var purchaseUserId = await new Promise(function(resolve, reject){
		db.get('SELECT ID FROM USER WHERE ORIGINALTRANSACTIONID LIKE ?;', [req.body.unified_receipt.latest_receipt_info[0].original_transaction_id], function(err, row){
			if (!row){
				if (!req.attemptedRefreshCount){
					req.attemptedRefreshCount = 0;
				}
				req.attemptedRefreshCount++;
				console.log('there does not seem to be a user with this ID yet - retrying in 30 seconds. refresh attempt # ' + req.attemptedRefreshCount);
				if (req.attemptedRefreshCount > 120){
					console.log('failed to associate a user with transaction ' + req.body.unified_receipt.latest_receipt_info[0].original_transaction_id);
					return;
				}
				var thisTransaction = req;
				setTimeout(function(){
					processIOSTransaction(thisTransaction);
				}, 30000);
				resolve(0);
				return;
			}
			resolve(row.ID);
		});
	});
	if (purchaseUserId == 0){
		return;
	}
	//console.log(req.body);
	console.log('users id for a transaction is ' + purchaseUserId);
	
	if (req.body.notification_type == "INITIAL_BUY" || req.body.notification_type == "DID_RENEW" || req.body.notification_type == "INTERACTIVE_RENEWAL"){	
		if (req.body.auto_renew_product_id == "sgsingleuser"){
			db.run('UPDATE USER SET LICENSETYPE = 2 WHERE ID = ?;', [purchaseUserId], err => {});
			console.log('upgraded user to single license');
		}
		else{
			db.run('UPDATE USER SET LICENSETYPE = 3 WHERE ID = ?;', [purchaseUserId], err => {});
			console.log('upgraded user to business license');
		}
	}
	if (req.body.notification_type == "DID_CHANGE_RENEWAL_STATUS" && req.body.auto_renew_status == "false"){
		console.log('downgrading user to normal license');
		db.run('UPDATE USER SET LICENSETYPE = 1 WHERE ID = ?;', [purchaseUserId], err => {});
	}
	if (req.body.notification_type == "DID_FAIL_TO_RENEW" && req.body.is_in_billing_retry_period == "false"){
		console.log('downgrading user to normal license');
		db.run('UPDATE USER SET LICENSETYPE = 1 WHERE ID = ?;', [purchaseUserId], err => {});
	}
}
app.get('/ping', function(req, res){
	res.sendStatus(200);
});
app.post("/validateAddress", function(req, res){
  var inputXML= `
  <AddressValidateRequest USERID="394JKSOF5449">
  <Revision>1</Revision>
  <Address ID="0">
  <Address1/>
  <Address2>${req.body.Address}</Address2>
  <City>${req.body.City}</City>
  <State>${req.body.State}</State>
  <Zip5>${req.body.ZIP.substring(0, 5)}</Zip5>
  <Zip4/>
  </Address>
  </AddressValidateRequest>
  `
  inputXML.split("\n").join("");
  rp('https://secure.shippingapis.com/ShippingAPI.dll?API=Verify&XML='+inputXML).then(function(htmlString){
   // console.log(htmlString);
    if (htmlString.includes("<Error>")){
      res.send("0");
      return;
    }
    if (htmlString.includes("<Footnotes>")){
      var FNC = htmlString.split("<Footnotes>")[1].split("</Footnotes>")[0];
      var disallowedCodes = ['B', 'C', 'V']
      for (var code of disallowedCodes){
        if (FNC.includes(code)){
          res.send("0");
          return;
        }
      }
    }
    res.send("1")
  })
});
app.post('/checkEmailUsername', async function(req, res){
	var username = req.body.username;
	var email = req.body.email;
	var usernameIsInUse = false;
	var emailIsInUse = false;
	//status codes
	//0 - both are good 
	//1 - email is in use
	//2 - username is in use
	if (username) {
		usernameIsInUse = await new Promise(function(resolve, reject){
			db.get('SELECT ID FROM USER WHERE LOWER(USERNAME) LIKE LOWER(?);', [username], function(err, row){
				if (row){
					resolve(true);
					return;
				}
				resolve(false);
			});
		});	
	}
	if (email){
		emailIsInUse = await new Promise(function(resolve, reject){
			db.get('SELECT ID FROM USER WHERE LOWER(EMAIL) LIKE LOWER(?);', [email], function(err, row){
				if (row){
					resolve(true);
					return;
				}
				resolve(false);
			});
		});
	}
	if (emailIsInUse){
		res.send("1");
		return;
	}
	if (usernameIsInUse){
		res.send("2");
		return;
	}
	res.send("0");
});
app.post('/register', function(req, res){
	var requiredKeys = ["username", "password", "email"];
	for (var key of requiredKeys){
		if (!req.body[key]){
			res.sendStatus(400);
			return;
		}
	}
	authModule.register(db, req.body.email, req.body.username, req.body.password).then(function(token){
		res.send(token);
	}).catch(function(failed){
		res.sendStatus(418);
	});
});
app.post('/login', function(req, res){
	var requiredKeys = ["username", "password"];
	for (var key of requiredKeys){
		if (!req.body[key]){
			res.sendStatus(400);
			return;
		}
	}
	authModule.login(db, req.body.username, req.body.password).then(function(token){
		res.send(token);
	}).catch(function(failed){
		res.sendStatus(401);
	});
});
app.post('/requestPasswordReset', function(req, res){
	var requestToken = authModule.generateToken();
	db.get('SELECT ID FROM USER WHERE EMAIL LIKE ?', [req.body.email], function(err, row){
		if (row){
			emailModule.sendReset(req.body.email, 'https://storeguard.app/openResetPassword.html?requestToken=' + requestToken);
			//console.log('https://storeguard.app/openResetPassword.html?requestToken=' + requestToken);
			db.run('UPDATE USER SET PASSWORDRESET = ? WHERE ID = ?;', [requestToken, row.ID], err => {});
			res.sendStatus(200);
		}
		else{
			res.sendStatus(400);
		}
	});
});
app.post('/resetPassword', function(req, res){
	var resetToken = req.body.resetToken;
	authModule.resetPassword(db, resetToken, req.body.newPassword).then(() => {
		res.sendStatus(200);
	}).catch(() => {
		res.sendStatus(400);
	});
});
app.get('/getLicenseType', function(req, res){
	//console.log('got to license request');
	//console.log(req.authUserId);
	db.get('SELECT LICENSETYPE FROM USER WHERE ID = ?;', [req.authUserId], function(err, row){
		res.send(row.LICENSETYPE + "");
	});
});
app.get('/refreshToken', function(req, res){
	var newToken = authModule.generateToken();
	db.run('UPDATE USER SET TOKEN = ? WHERE ID = ?;', [newToken, req.authUserId], function(err){
		res.send(newToken);
	});
});
app.post("/create-checkout-session", async (req, res) => {
  //console.log(req.body.token);
  const priceId = req.body.priceId;
  // See https://stripe.com/docs/api/checkout/sessions/create
  // for additional parameters to pass.
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
	  client_reference_id: req.authUserId,
      line_items: [
        {
          price: priceId,
          // For metered billing, do not pass quantity
          quantity: 1,
        },
      ],
      // {CHECKOUT_SESSION_ID} is a string literal; do not change it!
      // the actual Session ID is returned in the query parameter when your customer
      // is redirected to the success page.
      success_url: 'https://storeguard.app/completed.html?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'https://example.com/canceled.html',
    });
    res.send({
      sessionId: session.id,
    });
  } catch (e) {
    res.status(400);
    return res.send({
      error: {
        message: e.message,
      }
    });
  }
});
app.get("/initCheckout/:sessionId", function(req, res){
	res.send(`
		<html>
			<head>
				<script src="https://js.stripe.com/v3/"></script>
			</head>
			<body>
			Redirecting to billing...
			</body>
			<script>		
			var stripe = Stripe('pk_live_51IVNwVJdiPzoRJQFyMEqCmptUS475ZmRR3FXC8xbikQUMLuHuXWrb7WHRuPD8H0FmIxOTW7HCz8y1gGuFGSbQsdc002VoU1VAS');
			stripe.redirectToCheckout({
			  sessionId: '${req.params.sessionId}'
			})
			</script>
		</html>
	`);
});
app.get('/getCustomerPortalURL', async function(req, res){
	db.get('SELECT CUSTOMERID FROM USER WHERE ID LIKE ?;', [req.authUserId], async function(err, row){
		const portalsession = await stripe.billingPortal.sessions.create({
			customer: row.CUSTOMERID,
			return_url: "https://storeguard.app/exit.html",
		  });
		res.send(portalsession.url);
	});
});
app.post("/completedCheckout", function(req, res){
	//console.log(req.body);
	if (req.body.data.object.payment_status != "paid"){
		res.sendStatus(400);
		return;
	}
	if (!req.body.data.object.client_reference_id){
		res.sendStatus(400);
		return;
	}
	var licenseStatus;
	if (req.body.data.object.amount_total == 499 || req.body.data.object.amount_total == 50){
		licenseStatus = 2;
	}
	else{
		licenseStatus = 3;
	}
	db.run('UPDATE USER SET LICENSETYPE = ? WHERE ID = ?;', [licenseStatus, req.body.data.object.client_reference_id], err => {});
	db.run('UPDATE USER SET CUSTOMERID = ? WHERE ID = ?;', [req.body.data.object.customer, req.body.data.object.client_reference_id], err => {});
	//console.log('UPGRADED LICENSE');
	res.sendStatus(200);
});
app.post("/cancelledSubscription", function(req, res){
	//console.log('SUBSCRIPTION CANCELLED');
	db.run('UPDATE USER SET LICENSETYPE = 1 WHERE CUSTOMERID LIKE ?;', [req.body.data.object.customer], err => {});
	//console.log(req.body);
	res.sendStatus(200);
});
app.post("/appStoreNotification", async function(req, res){
	//console.log(JSON.stringify(req.body));
	processIOSTransaction(req);
	res.sendStatus(200);
});

app.post("/iosClientPurchase", function(req, res){
	console.log(`setting transaction id for user ${req.authUserId} to ${req.body.transactionId}`);
	db.run('UPDATE USER SET ORIGINALTRANSACTIONID = ? WHERE ID = ? AND ORIGINALTRANSACTIONID IS NULL;', [req.body.transactionId, req.authUserId]);
	res.sendStatus(200);
});
app.get("/getBillingPortalType", function(req, res){
	db.get('SELECT * FROM USER WHERE ID = ? AND ORIGINALTRANSACTIONID IS NOT NULL;', [req.authUserId], function(err, row){
		if (row){
			res.send("1"); //1 status code indicates ios original purchase
			return;
		}
		res.send("2"); //2 status code indicates android original purchase
	});
});
app.post('/generateCSV', async function(req, res){
	var accountEmail = await new Promise(function(resolve, reject){
		db.get('SELECT EMAIL FROM USER WHERE ID = ?;', [req.authUserId], function(err, row){
			resolve(row.EMAIL);
		});
	});
	if (!req.body.data){
		res.sendStatus(400);
		return;
	}
	var dataToWrite = dataModule.generateCSV(req.body.data);
	var filename = "export" + Date.now() + ".csv";
	fs.writeFile('/home/storeguard/static/csv/' + filename, dataToWrite, function(err){
		emailModule.sendCSV(accountEmail, '/home/storeguard/static/csv/' + filename);
		res.sendStatus(200);
		setTimeout(function(){fs.unlink('/home/storeguard/static/csv/' + filename, err => {})}, 10000);
	});
});
app.post('/sendSupport', async function(req,res){
	if (!req.body.username || !req.body.content){
		res.sendStatus(400);
		return;
	}
	axios.post('https://discord.com/api/webhooks/831663711780470815/K3UZ8xWRBOz8ljzzZraOZrGQveIk1bPZLwxRI7fY6kyzjPY5lMolp38W_gf-cSwvI7d0', {username: req.body.username, content: req.body.content});
	res.sendStatus(200);
});
http.createServer(app).listen(8004);
