const bcrypt = require('bcrypt');
exports.generateToken = function(){
  var tString = "";
  var usableTokenCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
  for (var i=0; i<40; i++){
    tString+=usableTokenCharacters[Math.floor(Math.random() * usableTokenCharacters.length)];
  }
  return tString;
}
exports.resolveUserId = function(db, token){
  if (!token){
    token = "a";
  }
  return new Promise(function(resolve, reject){
    db.get("SELECT ID FROM USER WHERE TOKEN LIKE ?;", [token], function(err, row){
      if (row){
        resolve(row.ID);
        return;
      }
      resolve(0);
      return;
    });
  });
}
exports.login = function(db, username, password){
	return new Promise(async function(resolveb, rejectb){
		 console.log('trying login');
		  var token = await new Promise(function(resolve, reject){
			db.get("SELECT TOKEN, PASSWORD FROM USER WHERE LOWER(?) LIKE LOWER(USERNAME);", [username], function(err, row){
			  if (!row){
				resolve("");
				return;
			  }
			  bcrypt.compare(password, row.PASSWORD, function(err2, res){
				if (res){
				  resolve(row.TOKEN);
				  return;
				}
				resolve("");
				return;
			  });
			});
		  });
		  if (token){
			resolveb(token);
		  }
		  else{
			rejectb()
		  }
	});
}
exports.register = function(db, email, username, password){
	return new Promise(async function(resolveb, rejectb){
		var isGenuine = await new Promise(function(resolve, reject){
		db.get('SELECT ID FROM USER WHERE LOWER(USERNAME) LIKE LOWER(?);', [username], function(err, row){
			  if (!row){
				resolve(true);
			  }
			  else{
				resolve(false);
			  }
			})
		  });
		  if (!isGenuine){
			rejectb();
			return;
		  }
		  var password2 = await new Promise(function(resolve, reject){
			bcrypt.hash(password, 10, function(err, hash){
			  resolve(hash);
			});
		  });
		  var token = exports.generateToken();
		  console.log(token);
		  db.run('INSERT INTO USER (USERNAME, PASSWORD, EMAIL, TOKEN, LICENSETYPE) VALUES (?, ?, ?, ?, 1);',
			[username, password2, email, token],
			function(){
			  resolveb(token);
			})
	});
} 
exports.resetPassword = function(db, resetToken, newPassword){
	return new Promise(async function(resolve, reject){
		db.get('SELECT ID FROM USER WHERE PASSWORDRESET LIKE ?;', [resetToken], async function(err, row){
			if (!row){
				reject();
				return;
			}
			console.log(row.ID);
			console.log(newPassword);
			var password2 = await new Promise(function(resolve2, reject2){
				bcrypt.hash(newPassword, 10, function(err, hash){
				resolve2(hash);
				});
			});
			console.log(password2);
			db.run('UPDATE USER SET PASSWORD = ? WHERE ID = ?', [password2, row.ID], err => {});
			resolve();
		  });
		});
};