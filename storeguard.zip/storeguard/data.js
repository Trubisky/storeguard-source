exports.generateCSV = function(data){
	var CSVString = "Name,Sex,Date of Birth,Height,Weight,Address,City,State,ZIP,Passed,Timestamp";
	var keyOrder = ['FullName', 'Sex', 'DateOfBirth', 'Height', 'Weight', 'Address', 'City', 'State', 'ZIP'];
	CSVString += "\r\n";
	for (var entry of data){
		for (var key of keyOrder){
			if (entry.licenseData[key]){
				CSVString+=entry.licenseData[key]+","
			}
			else{
				CSVString+=",";
			}
		}
		CSVString+=(entry.passed == 'true' ? 'Yes' : 'No') + ",";
		CSVString+=entry.timestamp.split(",").join("")+"\r\n";
	}
	return CSVString;
}
